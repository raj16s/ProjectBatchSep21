num = int(input("Enter a number: "))
if num % 2 == 0:
    print(" is Even".format(num))
else:
    print(" is Odd".format(num))





